import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const LOGO_URL = "https://lh3.googleusercontent.com/d/1l5kZFd5QCKfMQqCwXPlVbGv8ZRBI8rGi";
const PUBLIC_DIR = path.resolve('public');

async function main() {
  if (!fs.existsSync(PUBLIC_DIR)) {
    fs.mkdirSync(PUBLIC_DIR, { recursive: true });
  }

  console.log("Fetching logo from URL...");
  const response = await fetch(LOGO_URL);
  if (!response.ok) {
    throw new Error(`Failed to fetch logo: ${response.statusText}`);
  }
  const arrayBuffer = await response.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);

  // Save original buffer as logo.png
  fs.writeFileSync(path.join(PUBLIC_DIR, 'logo.png'), buffer);

  const sizes = [
    { name: 'favicon-16x16.png', size: 16 },
    { name: 'favicon-32x32.png', size: 32 },
    { name: 'favicon-48x48.png', size: 48 },
    { name: 'apple-touch-icon.png', size: 180 },
    { name: 'icon-192x192.png', size: 192 },
    { name: 'icon-512x512.png', size: 512 },
  ];

  for (const item of sizes) {
    await sharp(buffer)
      .resize(item.size, item.size, { fit: 'cover' })
      .png()
      .toFile(path.join(PUBLIC_DIR, item.name));
    console.log(`Generated ${item.name}`);
  }

  // Generate favicon.ico (32x32 standard png-based or raw)
  await sharp(buffer)
    .resize(32, 32, { fit: 'cover' })
    .png()
    .toFile(path.join(PUBLIC_DIR, 'favicon.ico'));
  console.log("Generated favicon.ico");

  // Create webmanifest
  const manifest = {
    name: "AH.DSGNNG",
    short_name: "AH.DSGNNG",
    icons: [
      {
        src: "/icon-192x192.png",
        sizes: "192x192",
        type: "image/png"
      },
      {
        src: "/icon-512x512.png",
        sizes: "512x512",
        type: "image/png"
      }
    ],
    theme_color: "#030712",
    background_color: "#030712",
    display: "standalone"
  };

  fs.writeFileSync(path.join(PUBLIC_DIR, 'site.webmanifest'), JSON.stringify(manifest, null, 2));
  console.log("Generated site.webmanifest");
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
