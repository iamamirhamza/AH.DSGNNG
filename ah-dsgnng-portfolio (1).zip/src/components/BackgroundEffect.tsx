export default function BackgroundEffect() {
  return (
    <div className="fixed inset-0 -z-50 overflow-hidden bg-[#030712] pointer-events-none select-none">
      {/* Deep Dark Matte Solid/Gradient Foundation */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#030712] via-[#050b18] to-[#02050c]" />

      {/* Subtle Micro Grid Overlay without neon glow */}
      <div 
        className="absolute inset-0 opacity-[0.035]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(255, 255, 255, 0.25) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.25) 1px, transparent 1px)
          `,
          backgroundSize: "48px 48px",
        }}
      />

      {/* Subtle Noise Texture */}
      <div className="absolute inset-0 noise-overlay opacity-20 mix-blend-overlay" />
    </div>
  );
}


