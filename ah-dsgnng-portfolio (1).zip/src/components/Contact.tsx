import { useState, ChangeEvent, FormEvent } from "react";
import { motion } from "motion/react";
import { Phone, Mail, MapPin, Send, Instagram, Facebook } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    service: "Graphic Designing - Modern Food Menu Design",
    message: ""
  });

  const mapsUrl = "https://www.google.com/maps/search/?api=1&query=Kaliachak,Malda,West+Bengal";

  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [id.replace("cf-", "")]: value
    }));
  };

  const handleFormSubmit = (e: FormEvent) => {
    e.preventDefault();
    const { name, phone, email, service, message } = formData;
    const emailBody = `Name: ${name}%0APhone: ${phone}%0AEmail: ${email}%0AService Interested In: ${service}%0A%0AMessage:%0A${message}`;
    window.location.href = `mailto:amirhamja1319@gmail.com?subject=New Project Inquiry: ${encodeURIComponent(service)} from ${encodeURIComponent(name)}&body=${emailBody}`;
  };

  return (
    <section id="contact" className="relative py-20 md:py-28 overflow-hidden">
      {/* Glow effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-cyan-500/10 blur-[130px] rounded-full pointer-events-none -z-10" />

      <div className="container mx-auto px-4 relative z-10">
        
        {/* Section Heading */}
        <div className="max-w-3xl mx-auto text-center mb-16 space-y-4 font-sans">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-cyan-400/30 bg-[#071329] text-[10px] font-bold tracking-[0.3em] text-cyan-300 uppercase shadow-[0_0_15px_rgba(14,165,233,0.2)] font-sans"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shrink-0 shadow-[0_0_8px_#22d3ee]" />
            Get In Touch
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-display font-extrabold text-3xl md:text-5xl leading-tight text-white tracking-tight"
          >
            <span className="text-white">Let's </span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500 font-extrabold drop-shadow-[0_0_25px_rgba(14,165,233,0.4)]">
              Work Together!
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-slate-300 text-base md:text-lg font-normal max-w-xl mx-auto leading-relaxed"
          >
            Great design is not just looking good,
            <br className="hidden sm:inline" />
            {" "}It’s about growing your business &amp; attracting loyal customers.
          </motion.p>
        </div>

        {/* Contact info cards grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start font-sans">
          
          {/* Left Details Panel */}
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.98 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ type: "spring", stiffness: 240, damping: 24 }}
            className="lg:col-span-5 space-y-6"
          >
            <motion.div 
              whileHover={{ y: -3 }}
              transition={{ type: "spring", stiffness: 350, damping: 25 }}
              className="p-8 rounded-3xl border border-cyan-500/20 space-y-6 shadow-xl bg-[#060e22]/90 backdrop-blur-xl group/card transform-gpu"
            >
              
              {/* Phone item */}
              <motion.div 
                whileHover={{ x: 4 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                className="flex items-center gap-4 py-3 border-b border-cyan-500/10 cursor-pointer group"
              >
                <div className="w-12 h-12 rounded-xl bg-[#081736] border border-cyan-400/30 flex items-center justify-center text-cyan-300 shrink-0 shadow-sm group-hover:scale-105 group-hover:bg-cyan-400 group-hover:text-black group-hover:border-cyan-300 transition-all duration-200">
                  <Phone size={18} />
                </div>
                <div>
                  <span className="block font-bold text-sm text-white">Phone</span>
                  <a href="tel:+917054307887" className="block text-xs sm:text-sm text-cyan-300 hover:text-white mt-0.5 transition-colors">
                    +91 7054307887
                  </a>
                </div>
              </motion.div>

              {/* Email item */}
              <motion.div 
                whileHover={{ x: 4 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                className="flex items-center gap-4 py-3 border-b border-cyan-500/10 cursor-pointer group"
              >
                <div className="w-12 h-12 rounded-xl bg-[#081736] border border-cyan-400/30 flex items-center justify-center text-cyan-300 shrink-0 shadow-sm group-hover:scale-105 group-hover:bg-cyan-400 group-hover:text-black group-hover:border-cyan-300 transition-all duration-200">
                  <Mail size={18} />
                </div>
                <div>
                  <span className="block font-bold text-sm text-white">Email</span>
                  <a href="mailto:amirhamja1319@gmail.com" className="block text-xs sm:text-sm text-cyan-300 hover:text-white mt-0.5 transition-colors">
                    amirhamja1319@gmail.com
                  </a>
                </div>
              </motion.div>

              {/* Location item */}
              <motion.div 
                whileHover={{ x: 4 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                className="flex items-center gap-4 py-3 cursor-pointer group"
              >
                <div className="w-12 h-12 rounded-xl bg-[#081736] border border-cyan-400/30 flex items-center justify-center text-cyan-300 shrink-0 shadow-sm group-hover:scale-105 group-hover:bg-cyan-400 group-hover:text-black group-hover:border-cyan-300 transition-all duration-200">
                  <MapPin size={18} />
                </div>
                <div>
                  <span className="block font-bold text-sm text-white">Location</span>
                  <span className="block text-xs sm:text-sm text-slate-300 mt-0.5">Kaliachak, Malda, West Bengal</span>
                </div>
              </motion.div>

              {/* Social links row with staggered interactive buttons */}
              <motion.div 
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.25 }}
                className="flex flex-wrap gap-2.5 pt-4"
              >
                <motion.a
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                  href="https://wa.me/917054307887"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-emerald-500/30 bg-[#062016]/90 text-xs text-emerald-300 hover:text-white hover:border-emerald-400 hover:bg-emerald-950/80 transition-colors shadow-sm"
                >
                  <svg className="w-4 h-4 fill-current text-emerald-400" viewBox="0 0 24 24">
                    <path d="M12.04 2c-5.46 0-9.9 4.44-9.9 9.9 0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.9-4.44 9.9-9.9 0-2.64-1.03-5.13-2.9-7C17.18 3.03 14.68 2 12.04 2z"/>
                  </svg>
                  WhatsApp
                </motion.a>
                <motion.a
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                  href="https://instagram.com/ah.dsgnng"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-pink-500/30 bg-[#250818]/90 text-xs text-pink-300 hover:text-white hover:border-pink-400 hover:bg-pink-950/80 transition-colors shadow-sm"
                >
                  <Instagram size={14} className="text-pink-400" />
                  Instagram
                </motion.a>
                <motion.a
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-blue-500/30 bg-[#081736]/90 text-xs text-blue-300 hover:text-white hover:border-blue-400 hover:bg-blue-950/80 transition-colors shadow-sm"
                >
                  <Facebook size={14} className="text-blue-400" />
                  Facebook
                </motion.a>
                <motion.a
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                  href={mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-cyan-500/30 bg-[#071329]/90 text-xs text-cyan-300 hover:text-white hover:border-cyan-400 hover:bg-[#0b214f] transition-colors shadow-sm"
                >
                  <MapPin size={14} className="text-cyan-400" />
                  Google Maps
                </motion.a>
              </motion.div>

            </motion.div>
          </motion.div>

          {/* Right Direct Email Form */}
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.98 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ type: "spring", stiffness: 240, damping: 24, delay: 0.1 }}
            className="lg:col-span-7"
          >
            <motion.form 
              whileHover={{ y: -3 }}
              transition={{ type: "spring", stiffness: 350, damping: 25 }}
              onSubmit={handleFormSubmit} 
              className="p-8 rounded-3xl border border-cyan-500/20 bg-[#060e22]/90 backdrop-blur-xl space-y-5 shadow-xl transform-gpu"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Full name input */}
                <div className="flex flex-col gap-2">
                  <label htmlFor="cf-name" className="text-xs text-slate-300 font-semibold tracking-wide">
                    Full Name
                  </label>
                  <input
                    id="cf-name"
                    type="text"
                    required
                    placeholder="Your name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="bg-[#081530] border border-cyan-500/20 rounded-xl px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition-all duration-200"
                  />
                </div>
                {/* Phone input */}
                <div className="flex flex-col gap-2">
                  <label htmlFor="cf-phone" className="text-xs text-slate-300 font-semibold tracking-wide">
                    Phone
                  </label>
                  <input
                    id="cf-phone"
                    type="tel"
                    placeholder="Your phone number"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="bg-[#081530] border border-cyan-500/20 rounded-xl px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition-all duration-200"
                  />
                </div>
              </div>

              {/* Email Input */}
              <div className="flex flex-col gap-2">
                <label htmlFor="cf-email" className="text-xs text-slate-300 font-semibold tracking-wide">
                  Email
                </label>
                <input
                  id="cf-email"
                  type="email"
                  required
                  placeholder="you@example.com"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="bg-[#081530] border border-cyan-500/20 rounded-xl px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition-all duration-200"
                />
              </div>

              {/* Service Selection */}
              <div className="flex flex-col gap-2">
                <label htmlFor="cf-service" className="text-xs text-slate-300 font-semibold tracking-wide">
                  Service You Need
                </label>
                <select
                  id="cf-service"
                  value={formData.service}
                  onChange={handleInputChange}
                  className="bg-[#081530] border border-cyan-500/20 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition-all duration-200 cursor-pointer"
                >
                  <optgroup label="🎨 Graphic Designing" className="bg-[#071329] text-cyan-300 font-semibold">
                    <option value="Poster Design" className="bg-[#071329] text-white">Poster Design</option>
                    <option value="Banner Design" className="bg-[#071329] text-white">Banner Design</option>
                    <option value="Modern Food Menu Design" className="bg-[#071329] text-white">Modern Food Menu Design</option>
                    <option value="Flyers Design" className="bg-[#071329] text-white">Flyers Design</option>
                    <option value="Medical Carousel Design" className="bg-[#071329] text-white">Medical Carousel Design</option>
                    <option value="Social Media Post & Ads Design" className="bg-[#071329] text-white">Social Media Post &amp; Ads Design</option>
                  </optgroup>
                  <optgroup label="📱 Digital Service for Restaurant" className="bg-[#071329] text-cyan-300 font-semibold">
                    <option value="Digital QR Menu" className="bg-[#071329] text-white">Digital QR Menu</option>
                    <option value="Digital Feedback Website" className="bg-[#071329] text-white">Digital Feedback Website</option>
                  </optgroup>
                  <optgroup label="🚀 Freelancing Service" className="bg-[#071329] text-cyan-300 font-semibold">
                    <option value="Social Media Management (Instagram & Facebook Modern Posts)" className="bg-[#071329] text-white">Social Media Management (Instagram &amp; Facebook Modern Posts)</option>
                  </optgroup>
                  <optgroup label="✨ Other Inquiries" className="bg-[#071329] text-cyan-300 font-semibold">
                    <option value="Complete Branding & Digital Package" className="bg-[#071329] text-white">Complete Branding &amp; Digital Package</option>
                    <option value="Custom Requirement" className="bg-[#071329] text-white">Custom Requirement</option>
                  </optgroup>
                </select>
              </div>

              {/* Message box */}
              <div className="flex flex-col gap-2">
                <label htmlFor="cf-msg" className="text-xs text-slate-300 font-semibold tracking-wide">
                  Message
                </label>
                <textarea
                  id="cf-msg"
                  required
                  placeholder="Tell me about your project..."
                  value={formData.message}
                  onChange={handleInputChange}
                  className="bg-[#081530] border border-cyan-500/20 rounded-xl px-4 py-3 text-sm text-white placeholder:text-slate-500 min-h-[120px] focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition-all duration-200"
                />
              </div>

              {/* Submit trigger with interactive spring physics */}
              <motion.button
                whileHover={{ scale: 1.015, y: -2 }}
                whileTap={{ scale: 0.97 }}
                transition={{ type: "spring", stiffness: 450, damping: 25 }}
                type="submit"
                className="w-full flex items-center justify-center gap-2.5 px-8 py-4 rounded-full text-sm font-black text-black bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 shadow-md hover:shadow-lg transition-all duration-200 cursor-pointer border border-cyan-200/50 select-none group/btn"
              >
                <span>Send Message</span>
                <Send size={15} strokeWidth={3} className="transition-transform duration-200 group-hover/btn:translate-x-1 group-hover/btn:-translate-y-0.5" />
              </motion.button>

              <p className="text-[10px] text-slate-400 leading-normal text-center mt-2">
                This form opens your email app with the message pre-filled — no data is stored.
              </p>
            </motion.form>
          </motion.div>

        </div>

        {/* Lower Map panel */}
        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.98 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ type: "spring", stiffness: 240, damping: 24, delay: 0.15 }}
          whileHover={{ y: -2 }}
          className="p-8 rounded-3xl border border-cyan-500/20 text-center mt-12 flex flex-col sm:flex-row items-center justify-between gap-6 overflow-hidden bg-[#060e22]/90 backdrop-blur-xl shadow-xl font-sans transform-gpu"
        >
          <div className="flex items-center gap-4 text-left">
            <div className="w-11 h-11 rounded-full bg-[#081736] border border-cyan-400/30 flex items-center justify-center text-cyan-300 shrink-0 shadow-sm">
              <MapPin size={18} />
            </div>
            <div>
              <span className="block font-bold text-sm text-white">Kaliachak, Malda, West Bengal — 732201</span>
              <span className="block text-xs text-slate-300 mt-0.5">Let's meet up or collaborate remotely worldwide!</span>
            </div>
          </div>
          <motion.a
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            transition={{ type: "spring", stiffness: 400, damping: 20 }}
            href={mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 rounded-full text-xs font-bold tracking-wide border border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-500/10 text-cyan-200 hover:text-white transition-colors whitespace-nowrap shadow-sm"
          >
            Open in Google Maps
          </motion.a>
        </motion.div>

      </div>
    </section>
  );
}
