import { useState } from "react";
import { motion } from "motion/react";

interface LogoImageProps {
  className?: string;
  imgClassName?: string;
  glowColor?: string;
}

export default function LogoImage({ 
  className = "w-16 h-16", 
  imgClassName = ""
}: LogoImageProps) {
  const [imgFailed, setImgFailed] = useState(false);
  const logoUrl = "https://lh3.googleusercontent.com/d/1l5kZFd5QCKfMQqCwXPlVbGv8ZRBI8rGi";

  return (
    <div 
      className={`relative rounded-full bg-[#030712] border-2 border-cyan-500/40 flex items-center justify-center overflow-hidden transition-all duration-300 group shadow-md ${className}`}
    >
      {!imgFailed ? (
        <img 
          src={logoUrl} 
          alt="Amir Hamja Logo" 
          className={`w-full h-full object-cover select-none relative z-0 transition-transform duration-300 group-hover:scale-105 ${imgClassName}`}
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
        />
      ) : (
        <span className="font-display font-extrabold text-transparent bg-clip-text bg-gradient-to-br from-[#ffffff] via-[#38bdf8] to-[#0ea5e9] tracking-wider select-none leading-none relative z-0 text-sm">
          AH
        </span>
      )}
    </div>
  );
}
