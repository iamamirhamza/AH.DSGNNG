import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight, 
  ExternalLink, 
  Smartphone, 
  QrCode, 
  Star, 
  MessageSquareHeart, 
  Share2, 
  TrendingUp, 
  Clock, 
  ShieldCheck, 
  Send,
  UtensilsCrossed,
  Layers,
  HeartPulse,
  Palette,
  Eye,
  ChevronRight,
  Instagram,
  Facebook,
  Heart,
  MessageCircle,
  Bookmark,
  ThumbsUp,
  Share
} from "lucide-react";

export interface ServiceDetailData {
  id: string;
  num: string;
  categoryKey: "graphic" | "digital" | "freelance";
  categoryLabel: string;
  title: string;
  subtitle: string;
  desc: string;
  icon: any;
  tags: string[];
  features: string[];
  benefits: string[];
  deliverables?: string[];
  targetNiches?: string[];
  demoType?: "qr-menu" | "feedback" | "social-media" | "graphic-showcase";
}

interface ServiceDetailModalProps {
  service: ServiceDetailData | null;
  onClose: () => void;
}

export default function ServiceDetailModal({ service, onClose }: ServiceDetailModalProps) {
  // Close on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    if (service) {
      document.body.style.overflow = "hidden";
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.body.style.overflow = "unset";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [service, onClose]);

  // Demo state for QR Menu
  const [activeMenuCategory, setActiveMenuCategory] = useState<string>("special");
  
  // Demo state for Feedback
  const [feedbackRating, setFeedbackRating] = useState<number>(5);
  const [feedbackSubmitted, setFeedbackSubmitted] = useState<boolean>(false);

  // Demo state for Social Media
  const [activeSocialTab, setActiveSocialTab] = useState<"instagram" | "facebook" | "niches">("instagram");

  if (!service) return null;

  const IconComponent = service.icon;

  return (
    <AnimatePresence>
      {service && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto">
          {/* Backdrop Blur */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-md -z-10"
          />

          {/* Modal Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-4xl bg-[#060e22] border border-cyan-500/30 rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col text-slate-100 backdrop-blur-2xl"
          >
            {/* Top Deep Blue Accent Bar */}
            <div className="h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />

            {/* Modal Header */}
            <div className="p-6 sm:p-8 border-b border-cyan-500/20 flex items-start justify-between gap-4 relative bg-gradient-to-b from-[#071533] to-[#060e22]">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-2xl bg-[#0a1b3d] border border-cyan-400/40 flex items-center justify-center text-cyan-300 shrink-0 shadow-sm">
                  <IconComponent size={28} />
                </div>
                <div>
                  <div className="flex items-center gap-2.5 mb-1.5 flex-wrap">
                    <span className="text-[10px] font-mono font-bold tracking-widest px-2.5 py-0.5 rounded-full border border-cyan-400/30 bg-cyan-500/10 text-cyan-300 uppercase">
                      {service.categoryLabel}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      Service #{service.num}
                    </span>
                  </div>
                  <h3 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight">
                    {service.title}
                  </h3>
                  <p className="text-sm text-cyan-300 font-medium mt-1 max-w-xl">
                    {service.subtitle}
                  </p>
                </div>
              </div>

              {/* Close Button */}
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-[#0a1838] border border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-500/20 text-cyan-300 flex items-center justify-center transition-all duration-200 shrink-0 cursor-pointer"
                aria-label="Close modal"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-6 sm:p-8 overflow-y-auto space-y-8 custom-scrollbar">
              
              {/* Detailed Description */}
              <div className="bg-[#07132e]/80 border border-cyan-500/20 rounded-2xl p-5 sm:p-6 space-y-3">
                <h4 className="text-xs uppercase font-mono font-bold tracking-widest text-cyan-300 flex items-center gap-2">
                  <Sparkles size={14} className="text-cyan-400" />
                  Overview &amp; Purpose
                </h4>
                <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                  {service.desc}
                </p>
                <div className="flex flex-wrap gap-2 pt-2">
                  {service.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="text-xs px-3 py-1 rounded-lg bg-[#0a1a3a] border border-cyan-500/30 text-cyan-200 font-medium shadow-xs"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Interactive Demo Preview Section if applicable */}
              {service.demoType === "qr-menu" && (
                <div className="rounded-2xl border border-cyan-500/20 bg-[#071329]/60 p-5 sm:p-6 space-y-4">
                  <div className="flex items-center justify-between flex-wrap gap-2 border-b border-cyan-500/20 pb-3">
                    <div className="flex items-center gap-2">
                      <QrCode className="text-cyan-400" size={20} />
                      <h4 className="font-display font-bold text-white text-base">
                        Interactive Live QR Menu Preview
                      </h4>
                    </div>
                    <span className="text-[11px] text-emerald-300 bg-[#062419] border border-emerald-500/40 px-2.5 py-0.5 rounded-full font-mono flex items-center gap-1.5 font-medium shadow-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      Live Mobile Web Sim
                    </span>
                  </div>

                  {/* Phone Simulator Frame */}
                  <div className="max-w-md mx-auto bg-[#081530] border-2 border-cyan-500/30 rounded-3xl p-4 shadow-xl space-y-4">
                    {/* Simulated Header */}
                    <div className="bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-700 text-white rounded-2xl p-3.5 flex items-center justify-between shadow-xs">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center text-white">
                          <UtensilsCrossed size={16} />
                        </div>
                        <div>
                          <p className="font-bold text-xs text-white">THE GRAND BISTRO</p>
                          <p className="text-[10px] text-cyan-100">Table #04 • Digital Menu</p>
                        </div>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 bg-emerald-500 text-white rounded-full font-medium shadow-xs">
                        Open Now
                      </span>
                    </div>

                    {/* Category Tabs */}
                    <div className="flex gap-2 overflow-x-auto pb-1 text-xs">
                      {[
                        { id: "special", label: "🔥 Chef Specials" },
                        { id: "burgers", label: "🍔 Burgers & Rolls" },
                        { id: "drinks", label: "🍹 Coolers & Shakes" },
                      ].map((tab) => (
                        <button
                          key={tab.id}
                          onClick={() => setActiveMenuCategory(tab.id)}
                          className={`px-3 py-1.5 rounded-xl whitespace-nowrap text-xs font-semibold transition-all duration-200 cursor-pointer ${
                            activeMenuCategory === tab.id
                              ? "bg-cyan-500 text-black font-extrabold shadow-sm"
                              : "bg-[#0b1d42] text-slate-300 hover:bg-[#0f2757] border border-cyan-500/20"
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>

                    {/* Menu Items List in Demo */}
                    <div className="space-y-2.5">
                      {activeMenuCategory === "special" && (
                        <>
                          <div className="flex items-center justify-between p-3 rounded-xl bg-[#061129] border border-cyan-500/20 hover:border-cyan-400/50 transition-all">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-red-400" />
                                <h5 className="font-bold text-xs text-white">Smoked BBQ Sizzler</h5>
                              </div>
                              <p className="text-[10px] text-slate-400">Tender grilled steak with herb rice &amp; veggies</p>
                            </div>
                            <span className="font-space font-bold text-xs text-cyan-300 bg-cyan-950/80 px-2 py-1 rounded-lg border border-cyan-500/40">
                              ₹449
                            </span>
                          </div>
                          <div className="flex items-center justify-between p-3 rounded-xl bg-[#061129] border border-cyan-500/20 hover:border-cyan-400/50 transition-all">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                                <h5 className="font-bold text-xs text-white">Truffle Paneer Tikka</h5>
                              </div>
                              <p className="text-[10px] text-slate-400">Charcoal smoked cottage cheese with mint dip</p>
                            </div>
                            <span className="font-space font-bold text-xs text-cyan-300 bg-cyan-950/80 px-2 py-1 rounded-lg border border-cyan-500/40">
                              ₹329
                            </span>
                          </div>
                        </>
                      )}

                      {activeMenuCategory === "burgers" && (
                        <>
                          <div className="flex items-center justify-between p-3 rounded-xl bg-[#061129] border border-cyan-500/20 hover:border-cyan-400/50 transition-all">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-red-400" />
                                <h5 className="font-bold text-xs text-white">Double Cheese Monster Burger</h5>
                              </div>
                              <p className="text-[10px] text-slate-400">Loaded with cheddar, caramelized onions &amp; fries</p>
                            </div>
                            <span className="font-space font-bold text-xs text-cyan-300 bg-cyan-950/80 px-2 py-1 rounded-lg border border-cyan-500/40">
                              ₹279
                            </span>
                          </div>
                          <div className="flex items-center justify-between p-3 rounded-xl bg-[#061129] border border-cyan-500/20 hover:border-cyan-400/50 transition-all">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                                <h5 className="font-bold text-xs text-white">Crispy Peri-Peri Paneer Wrap</h5>
                              </div>
                              <p className="text-[10px] text-slate-400">Spicy toasted tortilla wrap with garlic dip</p>
                            </div>
                            <span className="font-space font-bold text-xs text-cyan-300 bg-cyan-950/80 px-2 py-1 rounded-lg border border-cyan-500/40">
                              ₹199
                            </span>
                          </div>
                        </>
                      )}

                      {activeMenuCategory === "drinks" && (
                        <>
                          <div className="flex items-center justify-between p-3 rounded-xl bg-[#061129] border border-cyan-500/20 hover:border-cyan-400/50 transition-all">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                                <h5 className="font-bold text-xs text-white">Electric Blue Lagoon Mojito</h5>
                              </div>
                              <p className="text-[10px] text-slate-400">Fresh mint, sparkling lime &amp; curacao syrup</p>
                            </div>
                            <span className="font-space font-bold text-xs text-cyan-300 bg-cyan-950/80 px-2 py-1 rounded-lg border border-cyan-500/40">
                              ₹169
                            </span>
                          </div>
                          <div className="flex items-center justify-between p-3 rounded-xl bg-[#061129] border border-cyan-500/20 hover:border-cyan-400/50 transition-all">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                                <h5 className="font-bold text-xs text-white">Belgian Chocolate Thickshake</h5>
                              </div>
                              <p className="text-[10px] text-slate-400">Rich dark cocoa with brownie chunks</p>
                            </div>
                            <span className="font-space font-bold text-xs text-cyan-300 bg-cyan-950/80 px-2 py-1 rounded-lg border border-cyan-500/40">
                              ₹189
                            </span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Interactive Demo for Digital Feedback Website */}
              {service.demoType === "feedback" && (
                <div className="rounded-2xl border border-cyan-500/20 bg-[#071329]/60 p-5 sm:p-6 space-y-4">
                  <div className="flex items-center justify-between flex-wrap gap-2 border-b border-cyan-500/20 pb-3">
                    <div className="flex items-center gap-2">
                      <MessageSquareHeart className="text-cyan-400" size={20} />
                      <h4 className="font-display font-bold text-white text-base">
                        Interactive Feedback Flow Simulation
                      </h4>
                    </div>
                    <span className="text-[11px] text-cyan-300 bg-cyan-500/10 border border-cyan-400/30 px-2.5 py-0.5 rounded-full font-mono font-medium">
                      Smart Review Router
                    </span>
                  </div>

                  <div className="max-w-md mx-auto bg-[#081530] border border-cyan-500/30 rounded-3xl p-5 shadow-[0_10px_35px_rgba(0,0,0,0.8)] text-center space-y-4">
                    <div className="space-y-1">
                      <p className="text-xs text-cyan-300 font-mono uppercase tracking-wider font-semibold">How was your dining experience?</p>
                      <h5 className="font-display font-bold text-lg text-white">Rate your visit with us</h5>
                    </div>

                    {/* Star Rating Selectors */}
                    <div className="flex justify-center items-center gap-2 py-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => {
                            setFeedbackRating(star);
                            setFeedbackSubmitted(false);
                          }}
                          className="p-1 cursor-pointer transform hover:scale-125 transition-transform"
                        >
                          <Star
                            size={28}
                            className={`${
                              star <= feedbackRating
                                ? "text-amber-400 fill-amber-400"
                                : "text-slate-600"
                            }`}
                          />
                        </button>
                      ))}
                    </div>

                    {/* Dynamic Intelligent Redirection Preview */}
                    <div className="p-4 rounded-2xl bg-[#061126] border border-cyan-500/20 text-left space-y-2">
                      {feedbackRating >= 4 ? (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs">
                            <CheckCircle2 size={16} />
                            <span>⭐ 4-5 Stars: Directs to Google 5-Star Review</span>
                          </div>
                          <p className="text-[11px] text-slate-300 leading-relaxed">
                            Happy guests are instantly routed to post on Google Maps to boost your SEO &amp; public ranking!
                          </p>
                          <button
                            type="button"
                            onClick={() => setFeedbackSubmitted(true)}
                            className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-black font-extrabold text-xs rounded-xl shadow-md cursor-pointer hover:opacity-95 transition-opacity"
                          >
                            {feedbackSubmitted ? "✓ Redirecting to Google Maps..." : "Submit &amp; Open Google Reviews"}
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                            <ShieldCheck size={16} />
                            <span>🛡️ 1-3 Stars: Captures Private Feedback</span>
                          </div>
                          <p className="text-[11px] text-slate-300 leading-relaxed">
                            Negative reviews are intercepted privately and sent directly to management's WhatsApp/email without going public!
                          </p>
                          <button
                            type="button"
                            onClick={() => setFeedbackSubmitted(true)}
                            className="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-extrabold text-xs rounded-xl hover:opacity-95 transition-colors cursor-pointer shadow-md"
                          >
                            {feedbackSubmitted ? "✓ Private Feedback Sent to Manager" : "Submit Private Feedback"}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Interactive Demo for Social Media Management (Instagram & Facebook Modern Post) */}
              {service.demoType === "social-media" && (
                <div className="rounded-2xl border border-cyan-500/20 bg-[#071329]/60 p-5 sm:p-6 space-y-4">
                  <div className="flex items-center justify-between flex-wrap gap-2 border-b border-cyan-500/20 pb-3">
                    <div className="flex items-center gap-2">
                      <Sparkles className="text-cyan-400" size={20} />
                      <h4 className="font-display font-bold text-white text-base">
                        Instagram &amp; Facebook Modern Post Showcase
                      </h4>
                    </div>
                    <span className="text-[11px] text-cyan-300 bg-cyan-500/10 border border-cyan-400/30 px-2.5 py-0.5 rounded-full font-mono font-medium">
                      Modern Post Designs Only
                    </span>
                  </div>

                  {/* Platform Switcher Tabs */}
                  <div className="flex gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={() => setActiveSocialTab("instagram")}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all duration-200 cursor-pointer ${
                        activeSocialTab === "instagram"
                          ? "bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-sm"
                          : "bg-[#0a1838] border border-cyan-500/20 text-slate-300 hover:text-white"
                      }`}
                    >
                      <Instagram size={15} />
                      Instagram Modern Post
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSocialTab("facebook")}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all duration-200 cursor-pointer ${
                        activeSocialTab === "facebook"
                          ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm"
                          : "bg-[#0a1838] border border-cyan-500/20 text-slate-300 hover:text-white"
                      }`}
                    >
                      <Facebook size={15} />
                      Facebook Modern Post
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSocialTab("niches")}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all duration-200 cursor-pointer ${
                        activeSocialTab === "niches"
                          ? "bg-cyan-500 text-black font-extrabold shadow-sm"
                          : "bg-[#0a1838] border border-cyan-500/20 text-slate-300 hover:text-white"
                      }`}
                    >
                      <CheckCircle2 size={15} />
                      Niche Categories
                    </button>
                  </div>

                  {/* Tab 1: Instagram Modern Post Simulator */}
                  {activeSocialTab === "instagram" && (
                    <div className="max-w-md mx-auto bg-[#081530] border border-pink-500/30 rounded-3xl p-4 shadow-xl space-y-3.5">
                      {/* IG Post Header */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 p-[1.5px]">
                            <div className="w-full h-full rounded-full bg-[#081530] flex items-center justify-center text-[10px] font-bold text-white">
                              AH
                            </div>
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <p className="font-bold text-xs text-white">yourbrand.official</p>
                              <span className="w-3 h-3 rounded-full bg-cyan-400 flex items-center justify-center text-[8px] text-black font-bold">✓</span>
                            </div>
                            <p className="text-[10px] text-slate-400">Sponsored • Modern Visual Feed</p>
                          </div>
                        </div>
                        <span className="text-slate-400 text-xs">•••</span>
                      </div>

                      {/* IG Modern Creative Graphic Canvas */}
                      <div className="relative aspect-square w-full rounded-2xl bg-gradient-to-br from-[#061836] via-[#092557] to-[#040c1e] border border-cyan-400/30 p-5 flex flex-col justify-between overflow-hidden shadow-inner text-white">
                        <div className="relative z-10 flex justify-between items-start">
                          <span className="text-[10px] font-mono font-bold tracking-widest px-2.5 py-1 rounded-full bg-white/10 backdrop-blur-md border border-cyan-400/30 text-cyan-200 uppercase">
                            ✨ Special Offer Post
                          </span>
                          <span className="text-xs font-bold font-mono text-white bg-pink-500 px-2 py-0.5 rounded-lg shadow-sm">
                            50% OFF
                          </span>
                        </div>

                        <div className="relative z-10 space-y-2 text-center my-auto py-3">
                          <p className="text-[11px] text-cyan-300 font-mono tracking-wider uppercase font-semibold">
                            Modern • Aesthetic • High Converting
                          </p>
                          <h5 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight leading-tight">
                            EXPERIENCE THE EXTRAORDINARY
                          </h5>
                          <p className="text-[11px] text-slate-300 max-w-xs mx-auto">
                            Custom branded modern typography, clean minimal layout &amp; compelling visual hook.
                          </p>
                        </div>

                        <div className="relative z-10 flex items-center justify-between border-t border-cyan-500/20 pt-3">
                          <div className="text-left">
                            <p className="text-[9px] text-cyan-200 uppercase">Limited Time</p>
                            <p className="text-xs font-bold text-white">Book Your Table / Appointment</p>
                          </div>
                          <span className="px-3 py-1 rounded-full bg-cyan-400 text-black text-[11px] font-black shadow-sm">
                            Order Now →
                          </span>
                        </div>
                      </div>

                      {/* IG Post Interactions Bar */}
                      <div className="space-y-2 pt-1">
                        <div className="flex items-center justify-between text-slate-300">
                          <div className="flex items-center gap-3">
                            <Heart size={18} className="text-pink-500 fill-pink-500" />
                            <MessageCircle size={18} />
                            <Send size={18} />
                          </div>
                          <Bookmark size={18} />
                        </div>
                        <p className="text-[11px] font-bold text-white">1,428 likes</p>
                        <p className="text-[11px] text-slate-300">
                          <span className="font-bold text-white mr-1.5">yourbrand.official</span>
                          Elevate your feed with modern, high-converting graphic posts designed to attract more local clients. #ModernDesign #SocialGrowth
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Tab 2: Facebook Modern Post Simulator */}
                  {activeSocialTab === "facebook" && (
                    <div className="max-w-md mx-auto bg-[#081530] border border-blue-500/30 rounded-3xl p-4 shadow-xl space-y-3.5">
                      {/* FB Post Header */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <div className="w-9 h-9 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center font-bold text-black text-xs shadow-md">
                            AH
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <p className="font-bold text-xs text-white">Business Page Name</p>
                              <span className="text-[10px] text-cyan-300 font-semibold">● Follow</span>
                            </div>
                            <p className="text-[10px] text-slate-400">Just now • 🌐 Public • Sponsored</p>
                          </div>
                        </div>
                        <span className="text-slate-400 text-xs">•••</span>
                      </div>

                      {/* FB Post Copy */}
                      <p className="text-xs text-slate-300 leading-relaxed">
                        Looking for clean, modern &amp; scroll-stopping social media creatives for your business? Get dedicated weekly &amp; monthly graphic post design designed for growth! 👇
                      </p>

                      {/* FB Modern Banner Creative */}
                      <div className="relative aspect-[16/9] w-full rounded-2xl bg-gradient-to-r from-[#041026] via-[#09224f] to-[#041026] border border-cyan-400/30 p-4 flex flex-col justify-between overflow-hidden shadow-md text-white">
                        <div className="relative z-10 flex justify-between items-center">
                          <span className="text-[9px] font-mono font-bold tracking-widest px-2 py-0.5 rounded bg-white/10 border border-cyan-400/30 text-cyan-200 uppercase">
                            Facebook Creative Feed
                          </span>
                          <span className="text-[10px] font-bold text-emerald-300">⭐ Top Rated</span>
                        </div>

                        <div className="relative z-10 my-auto py-1">
                          <h5 className="font-display font-extrabold text-xl text-white tracking-tight">
                            GROW YOUR BRAND WITH MODERN POSTS
                          </h5>
                          <p className="text-[10px] text-cyan-100 mt-0.5">
                            Tailored for Restaurants, Cafes, Dental &amp; Healthcare Clinics.
                          </p>
                        </div>

                        <div className="relative z-10 flex items-center justify-between bg-black/40 backdrop-blur-sm px-3 py-1.5 rounded-xl border border-cyan-500/20">
                          <span className="text-[10px] text-slate-300 font-mono">Special Monthly Package Available</span>
                          <span className="text-[10px] font-bold text-black bg-cyan-400 px-2.5 py-0.5 rounded-lg shadow-xs">Send Message</span>
                        </div>
                      </div>

                      {/* FB Post Engagement Bar */}
                      <div className="space-y-2 border-t border-cyan-500/20 pt-2">
                        <div className="flex items-center justify-between text-[11px] text-slate-400">
                          <div className="flex items-center gap-1.5">
                            <span className="w-4 h-4 rounded-full bg-blue-600 flex items-center justify-center text-[9px] text-white">👍</span>
                            <span className="w-4 h-4 rounded-full bg-red-500 flex items-center justify-center text-[9px] text-white">❤️</span>
                            <span>384</span>
                          </div>
                          <span>42 Comments • 18 Shares</span>
                        </div>

                        <div className="grid grid-cols-3 gap-1 border-t border-cyan-500/20 pt-2 text-center text-xs text-slate-300 font-semibold">
                          <button type="button" className="flex items-center justify-center gap-1.5 py-1 hover:bg-[#0a1838] rounded-lg transition-colors cursor-pointer text-cyan-300">
                            <ThumbsUp size={14} /> Like
                          </button>
                          <button type="button" className="flex items-center justify-center gap-1.5 py-1 hover:bg-[#0a1838] rounded-lg transition-colors cursor-pointer text-slate-300">
                            <MessageCircle size={14} /> Comment
                          </button>
                          <button type="button" className="flex items-center justify-center gap-1.5 py-1 hover:bg-[#0a1838] rounded-lg transition-colors cursor-pointer text-slate-300">
                            <Share size={14} /> Share
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Tab 3: Specialized Niches */}
                  {activeSocialTab === "niches" && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div className="p-3.5 rounded-xl bg-[#071329] border border-cyan-500/30 shadow-xs space-y-1">
                        <h6 className="font-bold text-xs text-cyan-300 flex items-center gap-1.5">
                          <span>🍽️</span> Restaurants &amp; Cafes
                        </h6>
                        <p className="text-[11px] text-slate-300">
                          Delicious food specials, weekend discount banners, combo offers, festival menu launches &amp; ambiance posts.
                        </p>
                      </div>
                      <div className="p-3.5 rounded-xl bg-[#071329] border border-cyan-500/30 shadow-xs space-y-1">
                        <h6 className="font-bold text-xs text-cyan-300 flex items-center gap-1.5">
                          <span>🦷</span> Dental &amp; Orthodontics
                        </h6>
                        <p className="text-[11px] text-slate-300">
                          Smile makeover showcases, oral hygiene tips, painless treatment highlights &amp; patient awareness graphics.
                        </p>
                      </div>
                      <div className="p-3.5 rounded-xl bg-[#071329] border border-cyan-500/30 shadow-xs space-y-1">
                        <h6 className="font-bold text-xs text-cyan-300 flex items-center gap-1.5">
                          <span>🏥</span> Clinics, Hospitals &amp; Doctors
                        </h6>
                        <p className="text-[11px] text-slate-300">
                          Health awareness carousels, doctor OPD schedule banners, disease prevention advice &amp; clinic facilities.
                        </p>
                      </div>
                      <div className="p-3.5 rounded-xl bg-[#071329] border border-cyan-500/30 shadow-xs space-y-1">
                        <h6 className="font-bold text-xs text-cyan-300 flex items-center gap-1.5">
                          <span>🛍️</span> Modern Retail &amp; Local Brands
                        </h6>
                        <p className="text-[11px] text-slate-300">
                          Product feature grids, seasonal flash sales, testimonial reviews, new arrivals &amp; grand opening promotions.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* 2-Column Grid: Key Features & Business Benefits */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Features List */}
                <div className="space-y-3 p-5 rounded-2xl bg-[#07132e]/80 border border-cyan-500/20">
                  <h4 className="font-display font-bold text-base text-white flex items-center gap-2 border-b border-cyan-500/20 pb-3">
                    <CheckCircle2 className="text-cyan-400" size={18} />
                    Key Capabilities &amp; Features
                  </h4>
                  <ul className="space-y-2.5 text-xs sm:text-sm text-slate-300">
                    {service.features.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Business Benefits */}
                <div className="space-y-3 p-5 rounded-2xl bg-[#061e2b]/80 border border-emerald-500/30">
                  <h4 className="font-display font-bold text-base text-white flex items-center gap-2 border-b border-emerald-500/30 pb-3">
                    <TrendingUp className="text-emerald-400" size={18} />
                    Business Impact &amp; Growth ROI
                  </h4>
                  <ul className="space-y-2.5 text-xs sm:text-sm text-slate-300">
                    {service.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>

              </div>

            </div>

            {/* Modal Footer / Action CTA */}
            <div className="p-5 sm:p-6 bg-[#071129] border-t border-cyan-500/20 flex items-center justify-between gap-4 flex-wrap">
              <div className="text-xs text-slate-400 hidden sm:block">
                Ready to get started? Inquire now for custom pricing &amp; fast turnaround.
              </div>
              <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-full text-xs font-semibold text-slate-300 hover:text-white bg-[#0a1838] hover:bg-[#0e214c] border border-cyan-500/30 transition-colors cursor-pointer shadow-xs"
                >
                  Close
                </button>
                <a
                  href="#contact"
                  onClick={onClose}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-full text-xs sm:text-sm font-black text-black bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 shadow-md hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer border border-cyan-200/50"
                >
                  Order / Inquire This Service
                  <ArrowRight size={15} strokeWidth={3} />
                </a>
              </div>
            </div>

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
