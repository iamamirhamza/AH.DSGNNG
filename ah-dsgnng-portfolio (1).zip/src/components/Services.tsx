import { useState } from "react";
import { motion } from "motion/react";
import { 
  ImageIcon, 
  Layers, 
  UtensilsCrossed, 
  FileText, 
  HeartPulse, 
  Megaphone, 
  QrCode, 
  MessageSquareHeart, 
  Share2, 
  ArrowUpRight,
  Palette,
  Smartphone,
  Briefcase
} from "lucide-react";
import ServiceDetailModal, { ServiceDetailData } from "./ServiceDetailModal";

interface ServiceCategoryGroup {
  key: "graphic" | "digital" | "freelance";
  title: string;
  subtitle: string;
  badge: string;
  icon: any;
  items: ServiceDetailData[];
}

export default function Services() {
  const [selectedService, setSelectedService] = useState<ServiceDetailData | null>(null);

  const categoryGroups: ServiceCategoryGroup[] = [
    {
      key: "graphic",
      badge: "Category 01",
      title: "Graphic Designing Services",
      subtitle: "Custom visual designs, marketing creatives, and high-impact branding materials.",
      icon: Palette,
      items: [
        {
          id: "poster-design",
          num: "01",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Poster Design",
          subtitle: "High-impact promotional, event & launch posters",
          desc: "Bold, high-impact poster creatives designed for promotional campaigns, launch events, special offers, and brand announcements with crisp typography and striking visual balance.",
          icon: ImageIcon,
          tags: ["Print & Digital", "Event Posters", "High Resolution"],
          features: [
            "Ultra-High Resolution print-ready CMYK & digital RGB exports",
            "Custom illustrations, 3D text effects & photo compositing",
            "Standard size variations (A1, A2, A3, A4 & custom wall dimensions)",
            "Visual hierarchy engineered to grab attention within 2 seconds"
          ],
          benefits: [
            "Maximizes foot traffic and event ticket attendance",
            "Creates strong brand recall for seasonal discounts & offers",
            "Ready for instant printing with zero bleed or color distortion"
          ]
        },
        {
          id: "banner-design",
          num: "02",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Banner Design",
          subtitle: "Large format roll-up flex, outdoor signage & website hero graphics",
          desc: "Large-format exterior banners, roll-up flex displays, trade-show backdrops, and premium digital website hero graphics that command attention from afar.",
          icon: Layers,
          tags: ["Roll-up Banners", "Web Banners", "Outdoor Flex"],
          features: [
            "Vector-based high-res layouts scalable to any hoarding size",
            "Roll-up standee designs with clear contact & offer placements",
            "Digital web banners optimized for web speed and click-throughs",
            "Cohesive corporate and retail color palette adherence"
          ],
          benefits: [
            "Professional brand presence at exhibitions and storefronts",
            "High durability and clarity when printed on flex/vinyl materials",
            "Consistent visual storytelling across outdoor and online media"
          ]
        },
        {
          id: "modern-food-menu",
          num: "03",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Modern Food Menu Design",
          subtitle: "Appetizing culinary menu engineering for restaurants, cafes & lounges",
          desc: "Artistically crafted dining menus with appetizing visual hierarchy, clear categorization, and strategic layout flow engineered to maximize customer average order value.",
          icon: UtensilsCrossed,
          tags: ["Restaurant Menus", "Cafe Cards", "Table Tents"],
          features: [
            "Psychological menu engineering to highlight high-profit dishes",
            "Clear dietary tags (Veg, Non-Veg, Vegan, Chef Recommended, Spicy)",
            "Double-sided, trifold, booklet, and acrylic table tent formats",
            "Mouth-watering food photo retouching & color balancing"
          ],
          benefits: [
            "Increases average bill size by 15-25% through visual upselling",
            "Speeds up order selection time for faster table turnover",
            "Reinforces upscale restaurant aesthetics and guest satisfaction"
          ]
        },
        {
          id: "flyers-design",
          num: "04",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Flyers Design",
          subtitle: "Concise promotional leaflets for local distribution & direct sales",
          desc: "Eye-catching, concise promotional flyers engineered for direct handouts, local marketing drives, delivery inserts, discounts, and grand openings.",
          icon: FileText,
          tags: ["Promotional", "Direct Mail", "Double-Sided"],
          features: [
            "Single & double-sided A5 / DL flyer layouts",
            "High-contrast call-to-action buttons & coupon tear-off sections",
            "Organized bulleted product / service breakdowns",
            "Print-ready 300 DPI PDF files with trim and bleed marks"
          ],
          benefits: [
            "High direct response rate for localized geographic marketing",
            "Cost-effective promotional medium for special weekly deals",
            "Perfect for food delivery packaging inserts to trigger repeat orders"
          ]
        },
        {
          id: "medical-carousel",
          num: "05",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Medical Carousel Design",
          subtitle: "Informative, trustworthy swipeable carousel graphics for doctors & clinics",
          desc: "Informative, clean, and trustworthy swipeable carousel graphics tailored for doctors, hospitals, clinics, dental practitioners, and healthcare specialists to educate and build patient trust.",
          icon: HeartPulse,
          tags: ["Healthcare", "Clinic Awareness", "Swipe Carousels"],
          features: [
            "Seamless swipe flow designed specifically for Instagram & LinkedIn",
            "Patient education infographics (symptoms, treatments, preventive care)",
            "Doctor profile highlights, case studies & before/after templates",
            "Clean, professional healthcare typography & soothing medical palettes"
          ],
          benefits: [
            "Positions medical practitioners as trusted industry authorities",
            "High save & share rates on social platforms due to educational value",
            "Drives direct appointment inquiries from local patients"
          ]
        },
        {
          id: "social-media-posts-ads",
          num: "06",
          categoryKey: "graphic",
          categoryLabel: "Graphic Designing",
          title: "Social Media Post & Ads Design",
          subtitle: "Scroll-stopping social posts & high-converting Meta and Google ad creatives",
          desc: "High-converting ad creatives and scroll-stopping daily posts designed specifically for Meta (Instagram/Facebook) and Google Ads campaigns to capture interest in the first second.",
          icon: Megaphone,
          tags: ["Meta Ads", "Google Display", "Campaign Creatives"],
          features: [
            "Pixel-perfect 1:1 square & 9:16 story/reels aspect ratio formats",
            "A/B test creative variations for marketing campaigns",
            "Dynamic text overlays, badge stickers & promotional urgency triggers",
            "Strict compliance with Meta advertising guidelines"
          ],
          benefits: [
            "Lowers cost per lead (CPL) and cost per click (CPC) on paid ads",
            "Stops the endless scroll to capture genuine buyer interest",
            "Maintains high engagement and aesthetic consistency on brand profiles"
          ]
        }
      ]
    },
    {
      key: "digital",
      badge: "Category 02",
      title: "Digital Services for Restaurant",
      subtitle: "Smart contactless digital dining and customer feedback systems to modernize guest experiences.",
      icon: Smartphone,
      items: [
        {
          id: "digital-qr-menu",
          num: "07",
          categoryKey: "digital",
          categoryLabel: "Digital for Restaurant",
          title: "Digital QR Menu",
          subtitle: "Instant contactless digital dining web app for restaurants & cafes",
          desc: "Lightning-fast, mobile-friendly contactless dining menu web pages that load instantly upon scanning a tableside QR code. Zero app downloads required for guests, with instant category filtering, dietary tags, and high-definition dish photos.",
          icon: QrCode,
          tags: ["Instant QR Scan", "Zero App Download", "Fast Mobile Web"],
          demoType: "qr-menu",
          features: [
            "Instant Camera QR Scan — Loads in < 1 second on all smartphones",
            "100% Mobile Responsive with smooth food category tabs",
            "Veg / Non-Veg / Vegan / Chef Special dietary badges",
            "Real-time item availability toggle (mark sold-out dishes in 1 click)",
            "High-resolution dish photography & appetizing descriptions",
            "Custom-designed tableside QR acrylic standees & table stickers included"
          ],
          benefits: [
            "Zero reprint costs whenever menu items or prices change",
            "30% faster guest ordering and reduced waiting time",
            "Upsells high-margin chef specials with eye-catching visual cards",
            "Modern, eco-friendly, and hygienic dining experience"
          ]
        },
        {
          id: "digital-feedback-website",
          num: "08",
          categoryKey: "digital",
          categoryLabel: "Digital for Restaurant",
          title: "Digital Feedback Website",
          subtitle: "Interactive guest review & feedback platform with smart Google review router",
          desc: "Interactive guest feedback and review collection portal to gather real-time customer ratings, suggestions, and testimonial scores. Features a smart router that directs 5-star reviews to Google Maps while intercepting complaints privately.",
          icon: MessageSquareHeart,
          tags: ["Review Collection", "Customer Ratings", "Direct Feedback"],
          demoType: "feedback",
          features: [
            "1-to-5 Star Interactive Smart Rating System with emoji reactions",
            "Smart Review Routing: 4-5 Stars automatically redirect to Google Maps review page",
            "Private Feedback Shield: 1-3 Stars open private manager feedback box (preventing public bad reviews)",
            "Custom rating categories: Food Taste, Ambience, Staff Courtesy & Speed",
            "Instant WhatsApp / Email alert to owner on negative feedback",
            "Customer data capture (Name, Phone & Birthday for SMS marketing)"
          ],
          benefits: [
            "Boosts your restaurant's 5-Star Google rating and local SEO rank",
            "Privately resolves unhappy customer issues before they reach social media",
            "Builds a direct customer phone database for festival discount broadcasts",
            "Provides actionable feedback to improve kitchen and staff performance"
          ]
        }
      ]
    },
    {
      key: "freelance",
      badge: "Category 03",
      title: "Freelancing Services",
      subtitle: "Dedicated monthly Instagram & Facebook Modern Post design and aesthetic feed curation for businesses & healthcare.",
      icon: Briefcase,
      items: [
        {
          id: "social-media-management",
          num: "09",
          categoryKey: "freelance",
          categoryLabel: "Freelancing Service",
          title: "Social Media Management",
          subtitle: "Instagram & Facebook Modern Post Design & Monthly Feed Management",
          desc: "Dedicated monthly Instagram & Facebook modern post design, aesthetic feed curation, carousel graphics, and high-impact visual content tailored for restaurants, cafes, clinics, dentists & modern brands.",
          icon: Share2,
          tags: ["Instagram Modern Posts", "Facebook Feed Creatives", "Monthly Post Management"],
          demoType: "social-media",
          features: [
            "Exclusive Instagram & Facebook modern feed post and carousel designs",
            "High-converting promotional, product launch & discount offer posts",
            "Pixel-perfect 1:1 square & 4:5 portrait modern post layouts",
            "Brand aesthetic harmonization (custom brand fonts, colors & templates)",
            "Strategic monthly post schedule & content calendar planning",
            "Festival wishes, seasonal sale announcements & special highlights"
          ],
          benefits: [
            "Establishes a premium, modern visual feed on Instagram & Facebook",
            "Boosts post engagement, saves, and direct message inquiries",
            "Saves hours every week with ready-to-publish modern post designs",
            "Outperforms local competitors with clean, professional graphic branding"
          ]
        }
      ]
    }
  ];

  return (
    <section id="services" className="relative py-20 md:py-28 overflow-hidden bg-[#020204]">
      {/* Ambient background glows that seamlessly match the canvas */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[80vw] h-[50vw] bg-brand-blue/5 blur-[160px] rounded-full pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-brand-blue/5 blur-[140px] rounded-full pointer-events-none" />

      <div className="container mx-auto px-4 relative z-10 max-w-6xl">
        
        {/* Section Heading */}
        <div className="max-w-3xl mx-auto text-center mb-16 space-y-5 relative">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-cyan-400/30 bg-[#071329] text-[10px] font-bold tracking-[0.3em] text-cyan-300 uppercase shadow-sm font-sans"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            What I Offer
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-display font-black text-3xl sm:text-4xl md:text-5xl lg:text-6xl leading-[1.15] text-white tracking-tight max-w-3xl mx-auto"
            style={{ textWrap: "balance" }}
          >
            <span className="text-white">Our Creative </span>
            <span className="relative inline-block mt-1 sm:mt-0">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500 font-black">
                Services
              </span>
              <span className="absolute -bottom-2 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent rounded-full" />
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-slate-300 text-base md:text-lg font-normal max-w-2xl mx-auto leading-relaxed font-sans pt-1"
          >
            High-converting visual designs &amp; digital solutions engineered to elevate your brand presence and drive real customer engagement.
          </motion.p>
        </div>

        {/* Divided Category Blocks with iOS-Style Spring Animation */}
        <div className="space-y-12 md:space-y-16">
          {categoryGroups.map((group, groupIdx) => {
            const GroupIcon = group.icon;
            return (
              <motion.div 
                key={group.key}
                initial={{ opacity: 0, y: 35, scale: 0.98 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{
                  type: "spring",
                  stiffness: 240,
                  damping: 26,
                  mass: 0.8,
                  delay: groupIdx * 0.12,
                }}
                whileHover={{
                  y: -2,
                  transition: { type: "spring", stiffness: 350, damping: 25 }
                }}
                className="relative rounded-3xl border border-cyan-500/20 hover:border-cyan-400/40 bg-[#060e22]/90 backdrop-blur-xl shadow-xl p-6 sm:p-8 md:p-10 transition-colors duration-300 overflow-hidden group/block transform-gpu"
              >
                {/* Category Header Bar */}
                <div className="flex items-center justify-between gap-4 pb-5 mb-7 border-b border-cyan-500/15 relative z-10">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#081736] border border-cyan-400/30 flex items-center justify-center text-cyan-300 shrink-0 shadow-sm transition-transform duration-300 group-hover/block:scale-105">
                      <GroupIcon size={24} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2.5 mb-1.5">
                        <span className="text-[10px] font-mono uppercase font-bold tracking-widest px-2.5 py-0.5 rounded-full border border-cyan-400/30 bg-cyan-500/10 text-cyan-300">
                          {group.badge}
                        </span>
                        <span className="text-xs text-slate-400 font-mono font-medium">
                          {group.items.length} {group.items.length === 1 ? "Service" : "Services"}
                        </span>
                      </div>
                      <h3 className="font-display font-extrabold text-xl sm:text-2xl text-white tracking-tight">
                        {group.title}
                      </h3>
                    </div>
                  </div>
                </div>

                {/* Service Cards Grid for this Category */}
                <div className={`grid grid-cols-1 ${group.items.length > 2 ? 'md:grid-cols-2 lg:grid-cols-3' : group.items.length === 2 ? 'md:grid-cols-2' : 'max-w-xl'} gap-4 relative z-10`}>
                  {group.items.map((service, serviceIdx) => {
                    const IconComponent = service.icon;
                    return (
                      <motion.div
                        key={service.id}
                        onClick={() => setSelectedService(service)}
                        initial={{ opacity: 0, y: 15 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{
                          type: "spring",
                          stiffness: 280,
                          damping: 24,
                          delay: serviceIdx * 0.04,
                        }}
                        whileHover={{ 
                          scale: 1.015, 
                          y: -2,
                          transition: { type: "spring", stiffness: 400, damping: 25 }
                        }}
                        whileTap={{ 
                          scale: 0.965,
                          transition: { type: "spring", stiffness: 500, damping: 30 }
                        }}
                        className="relative p-5 rounded-2xl border border-cyan-500/15 hover:border-cyan-400/50 bg-[#07132b]/80 hover:bg-[#091a3c] group transition-colors duration-200 overflow-hidden flex items-center justify-between gap-4 transform-gpu cursor-pointer select-none"
                        role="button"
                        tabIndex={0}
                        aria-label={`View details for ${service.title}`}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            setSelectedService(service);
                          }
                        }}
                      >
                        <div className="flex items-center gap-3.5 relative z-10">
                          {/* Icon */}
                          <div className="w-10 h-10 rounded-xl border border-cyan-400/30 bg-[#061129] flex items-center justify-center shrink-0 shadow-sm text-cyan-300 group-hover:scale-105 group-hover:bg-cyan-400 group-hover:text-black group-hover:border-cyan-300 transition-all duration-250 ease-out">
                            <IconComponent size={20} />
                          </div>

                          {/* Main Title */}
                          <div>
                            <h4 className="font-display font-extrabold text-base sm:text-lg text-white group-hover:text-cyan-300 transition-colors duration-200 tracking-tight">
                              {service.title}
                            </h4>
                          </div>
                        </div>

                        {/* Number / Arrow */}
                        <div className="flex items-center gap-2 shrink-0 relative z-10">
                          <span className="font-space text-xs text-slate-500 font-bold tracking-widest group-hover:text-cyan-300 transition-colors duration-200">
                            {service.num}
                          </span>
                          <div className="w-7 h-7 rounded-full bg-[#0a1838] border border-cyan-500/20 group-hover:border-cyan-400/60 group-hover:bg-cyan-500/20 flex items-center justify-center transition-all">
                            <ArrowUpRight size={15} className="text-cyan-400 group-hover:text-cyan-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-200 ease-out" />
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>

      {/* Service Detail Modal Popup */}
      <ServiceDetailModal 
        service={selectedService} 
        onClose={() => setSelectedService(null)} 
      />
    </section>
  );
}

