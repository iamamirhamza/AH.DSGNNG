import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import LogoImage from "./LogoImage";
import { ArrowUpRight, Menu, X, Phone, MessageCircle } from "lucide-react";

interface HeaderProps {
  activeSection: string;
}

export default function Header({ activeSection }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Strictly lock body and HTML scroll when mobile menu is open
  useEffect(() => {
    if (isMobileOpen) {
      document.body.style.overflow = "hidden";
      document.documentElement.style.overflow = "hidden";
      document.body.style.touchAction = "none";
    } else {
      document.body.style.overflow = "";
      document.documentElement.style.overflow = "";
      document.body.style.touchAction = "";
    }
    return () => {
      document.body.style.overflow = "";
      document.documentElement.style.overflow = "";
      document.body.style.touchAction = "";
    };
  }, [isMobileOpen]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isMobileOpen) {
        setIsMobileOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isMobileOpen]);

  const menuItems = [
    { id: "home", label: "Home" },
    { id: "services", label: "Services" },
    { id: "contact", label: "Contact" },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-[#030712]/95 backdrop-blur-xl border-b border-cyan-500/20 py-3 shadow-lg"
            : "py-5 bg-transparent"
        }`}
      >
        <div className="container mx-auto px-4 flex items-center justify-between">
          {/* Logo / Brand */}
          <a href="#home" className="flex items-center gap-3 group">
            <LogoImage className="w-11 h-11 group-hover:scale-105 transition-transform duration-300" imgClassName="" />
            <div className="flex flex-col">
              <span className="font-display font-black text-sm tracking-wide text-white">
                AH <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-sky-300">DSGNNG</span>
              </span>
              <span className="text-[10px] text-cyan-300/80 uppercase tracking-[0.15em] font-semibold mt-0.5 font-sans">
                Designer &amp; Freelancer
              </span>
            </div>
          </a>

          {/* Desktop Nav Items */}
          <nav className="hidden lg:flex items-center gap-1.5 p-1 bg-[#060e22]/90 rounded-full border border-cyan-500/25 backdrop-blur-md font-sans shadow-md">
            {menuItems.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                className={`relative px-4 py-2 rounded-full text-xs font-semibold tracking-wide transition-all duration-300 ${
                  activeSection === item.id
                    ? "text-black font-bold bg-gradient-to-r from-cyan-400 via-sky-400 to-cyan-300 shadow-sm"
                    : "text-slate-300 hover:text-white hover:bg-white/5"
                }`}
              >
                {item.label}
              </a>
            ))}
          </nav>

          {/* Actions & Buttons */}
          <div className="flex items-center gap-3">
            {/* Hire Me button for Desktop */}
            <a
              href="#contact"
              className="hidden sm:inline-flex items-center justify-center px-5 py-2.5 rounded-full text-xs font-bold tracking-wider text-black bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 shadow-md hover:scale-[1.03] active:scale-[0.98] transition-all duration-300 font-sans cursor-pointer border border-cyan-200/40"
            >
              Hire Me
            </a>

            {/* Futuristic Animated Hamburger Button */}
            <button
              type="button"
              onClick={() => setIsMobileOpen((prev) => !prev)}
              className="lg:hidden w-11 h-11 rounded-2xl flex items-center justify-center border border-cyan-400/40 bg-[#071329]/90 hover:bg-[#0a1f42] text-cyan-300 transition-all duration-200 focus:outline-none cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.15)] active:scale-95 z-50"
              aria-label="Toggle menu"
              aria-expanded={isMobileOpen}
            >
              {isMobileOpen ? (
                <X size={22} className="text-cyan-300" />
              ) : (
                <Menu size={22} className="text-cyan-300" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Fullscreen View matching user's exact design */}
      <AnimatePresence>
        {isMobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-[100] bg-black flex flex-col justify-between px-6 py-5 sm:py-8 font-sans select-none overflow-hidden touch-none h-[100dvh] w-[100vw]"
            style={{ touchAction: "none" }}
          >
            {/* Top Bar: Logo & Close Button */}
            <div className="flex items-center justify-between w-full max-w-md mx-auto">
              <a
                href="#home"
                onClick={() => setIsMobileOpen(false)}
                className="flex items-center gap-3"
              >
                <div className="w-12 h-12 rounded-full ring-2 ring-cyan-400/40 p-0.5 bg-[#061126] flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                  <LogoImage className="w-10 h-10 rounded-full" imgClassName="rounded-full" />
                </div>
                <div className="flex flex-col text-left">
                  <div className="text-base font-black tracking-wide">
                    <span className="text-white">AH. </span>
                    <span className="text-cyan-400">DSGNNG</span>
                  </div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-[0.18em] font-semibold mt-0.5">
                    DESIGNER &amp; FREELANCER
                  </span>
                </div>
              </a>

              {/* Circular Dark Close Button */}
              <button
                type="button"
                onClick={() => setIsMobileOpen(false)}
                className="w-12 h-12 rounded-full bg-[#121826] border border-white/10 hover:border-cyan-400/40 flex items-center justify-center text-white/90 hover:text-cyan-300 transition-all duration-200 cursor-pointer shadow-lg active:scale-90"
                aria-label="Close menu"
              >
                <X size={20} />
              </button>
            </div>

            {/* Centered Main Menu Card */}
            <motion.div
              initial={{ scale: 0.94, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.94, opacity: 0, y: 10 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="w-full max-w-sm mx-auto my-auto rounded-[32px] bg-[#091322] border border-cyan-900/30 p-7 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.9),0_0_30px_rgba(6,182,212,0.1)] flex flex-col"
            >
              {/* Home Link */}
              <a
                href="#home"
                onClick={() => setIsMobileOpen(false)}
                className={`w-full py-4 text-center text-xl font-bold tracking-wide transition-colors ${
                  activeSection === "home"
                    ? "text-cyan-400 font-extrabold"
                    : "text-cyan-400 hover:text-cyan-300"
                }`}
              >
                Home
              </a>

              {/* Divider 1 */}
              <div className="w-full h-[1px] bg-slate-800/80" />

              {/* Services Link */}
              <a
                href="#services"
                onClick={() => setIsMobileOpen(false)}
                className={`w-full py-4 text-center text-xl font-bold tracking-wide transition-colors ${
                  activeSection === "services"
                    ? "text-cyan-400 font-extrabold"
                    : "text-slate-300 hover:text-white"
                }`}
              >
                Services
              </a>

              {/* Divider 2 */}
              <div className="w-full h-[1px] bg-slate-800/80" />

              {/* Contact Link */}
              <a
                href="#contact"
                onClick={() => setIsMobileOpen(false)}
                className={`w-full py-4 text-center text-xl font-bold tracking-wide transition-colors ${
                  activeSection === "contact"
                    ? "text-cyan-400 font-extrabold"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Contact
              </a>

              {/* CTA Button: Let's Work Together */}
              <a
                href="#contact"
                onClick={() => setIsMobileOpen(false)}
                className="mt-6 w-full py-4 px-6 rounded-2xl bg-cyan-500 hover:bg-cyan-400 active:bg-cyan-600 text-white font-bold text-base flex items-center justify-center gap-2 shadow-[0_10px_25px_rgba(6,182,212,0.3)] transition-all duration-200 cursor-pointer"
              >
                <span>Let's Work Together</span>
                <ArrowUpRight size={18} strokeWidth={2.5} />
              </a>
            </motion.div>

            {/* Bottom spacer / indicator */}
            <div className="w-full max-w-sm mx-auto text-center pb-2">
              <div className="w-32 h-1 bg-slate-800/60 rounded-full mx-auto" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
