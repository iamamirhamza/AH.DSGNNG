import LogoImage from "./LogoImage";
import { Instagram, Facebook } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative border-t border-white/5 bg-[#000000] py-16 overflow-hidden">
      <div className="container mx-auto px-4 relative z-10 font-sans">
        
        {/* Upper Column Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand Col */}
          <div className="space-y-5">
            <div className="flex items-center gap-3">
              <LogoImage className="w-12 h-12" imgClassName="" />
              <div className="flex flex-col">
                <span className="font-display font-black text-sm tracking-wide text-white">
                  AH <span className="text-brand-blue">DSGNNG</span>
                </span>
                <span className="text-[9px] text-[#94A3B8] uppercase tracking-widest font-semibold mt-0.5">
                  Designer &amp; Freelancer
                </span>
              </div>
            </div>
            <p className="text-[#94A3B8] text-xs md:text-sm font-normal leading-relaxed max-w-xs">
              Specializing in Social Media Management &amp; Graphic Design services to attract more customers and boost brand value.
            </p>
          </div>

          {/* Quick Links Column */}
          <div className="space-y-4">
            <h5 className="font-display font-bold text-xs tracking-widest uppercase text-white">
              Quick Links
            </h5>
            <ul className="space-y-2.5">
              <li>
                <a href="#home" className="text-[#94A3B8] text-xs sm:text-sm hover:text-brand-blue transition-colors duration-200 font-medium">
                  Home
                </a>
              </li>
              <li>
                <a href="#services" className="text-[#94A3B8] text-xs sm:text-sm hover:text-brand-blue transition-colors duration-200 font-medium">
                  Services
                </a>
              </li>
              <li>
                <a href="#contact" className="text-[#94A3B8] text-xs sm:text-sm hover:text-brand-blue transition-colors duration-200 font-medium">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Services Column */}
          <div className="space-y-4">
            <h5 className="font-display font-bold text-xs tracking-widest uppercase text-white">
              Services
            </h5>
            <ul className="space-y-2.5 font-medium">
              <li>
                <a href="#services" className="text-[#94A3B8] text-xs sm:text-sm hover:text-brand-blue transition-colors duration-200">
                  Menu Design
                </a>
              </li>
              <li>
                <a href="#services" className="text-[#94A3B8] text-xs sm:text-sm hover:text-brand-blue transition-colors duration-200">
                  Poster Design
                </a>
              </li>
              <li>
                <a href="#services" className="text-[#94A3B8] text-xs sm:text-sm hover:text-brand-blue transition-colors duration-200">
                  Social Media Posts
                </a>
              </li>
              <li>
                <a href="#services" className="text-[#94A3B8] text-xs sm:text-sm hover:text-brand-blue transition-colors duration-200">
                  QR Menu Website
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Details Column */}
          <div className="space-y-4">
            <h5 className="font-display font-bold text-xs tracking-widest uppercase text-white">
              Contact
            </h5>
            <ul className="space-y-2.5 text-[#94A3B8] text-xs sm:text-sm font-normal">
              <li>
                <a href="tel:+917054307887" className="hover:text-brand-blue transition-colors duration-200 font-medium">
                  +91 7054307887
                </a>
              </li>
              <li>
                <a href="mailto:ahdsgnng@email.com" className="hover:text-brand-blue transition-colors duration-200 font-medium">
                  ahdsgnng@email.com
                </a>
              </li>
              <li>
                <span className="font-medium">Kaliachak, Malda, WB</span>
              </li>
            </ul>

            {/* Social handles circle links */}
            <div className="flex gap-2.5 pt-2">
              <a
                href="https://wa.me/917054307887"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full border border-white/5 hover:border-brand-blue/40 bg-white/5 hover:bg-white/10 flex items-center justify-center text-soft-gray hover:text-white transition-all duration-300"
                aria-label="WhatsApp Link"
              >
                <svg className="w-4.5 h-4.5 fill-current" viewBox="0 0 24 24">
                  <path d="M12.04 2c-5.46 0-9.9 4.44-9.9 9.9 0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.9-4.44 9.9-9.9 0-2.64-1.03-5.13-2.9-7C17.18 3.03 14.68 2 12.04 2z"/>
                </svg>
              </a>
              <a
                href="https://instagram.com/ah.dsgnng"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full border border-white/5 hover:border-brand-blue/40 bg-white/5 hover:bg-white/10 flex items-center justify-center text-soft-gray hover:text-white transition-all duration-300"
                aria-label="Instagram Link"
              >
                <Instagram size={16} />
              </a>
              <a
                href="#"
                className="w-9 h-9 rounded-full border border-white/5 hover:border-brand-blue/40 bg-white/5 hover:bg-white/10 flex items-center justify-center text-soft-gray hover:text-white transition-all duration-300"
                aria-label="Facebook Link"
              >
                <Facebook size={16} />
              </a>
            </div>
          </div>

        </div>

        {/* Lower Meta Copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-8 border-t border-white/5 text-xs text-[#94A3B8] text-center font-normal">
          <span>
            &copy; {currentYear} <span className="text-brand-blue font-bold tracking-wider">AH DSGNNG</span> &bull; Empowering Brands with Creative Visuals &amp; Digital Solutions.
          </span>
        </div>

      </div>
    </footer>
  );
}
