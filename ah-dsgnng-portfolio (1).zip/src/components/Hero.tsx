import { motion } from "motion/react";
import LogoImage from "./LogoImage";
import { ArrowRight, Phone, Sparkles } from "lucide-react";

export default function Hero() {
  return (
    <section id="home" className="relative min-h-[90vh] py-24 md:py-32 flex items-center overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Centered Hero Content Column */}
          <div className="lg:col-span-10 lg:col-start-2 text-center space-y-8 flex flex-col items-center">
            
            {/* Available Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#071329] border border-cyan-400/40 text-xs font-semibold text-cyan-300 tracking-wide font-sans transform-gpu shadow-sm hover:border-cyan-400 transition-all duration-300"
            >
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              Available for Freelance Projects
            </motion.div>

            {/* Main Premium Typography */}
            <h1 className="font-display font-black text-5xl sm:text-6xl md:text-8xl lg:text-9xl leading-none tracking-tighter select-none">
              <span className="block overflow-hidden pb-1">
                <motion.span
                  initial={{ y: "100%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
                  className="block text-white transform-gpu"
                >
                  AH
                </motion.span>
              </span>
              <span className="block overflow-hidden pb-1">
                <motion.span
                  initial={{ y: "100%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1], delay: 0.22 }}
                  className="block text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500 font-black transform-gpu"
                >
                  DSGNNG
                </motion.span>
              </span>
            </h1>

            {/* Niche Role Badges */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: 0.35 }}
              className="flex flex-wrap gap-2.5 justify-center transform-gpu"
            >
              <span className="px-4 py-1.5 rounded-full text-xs font-semibold border border-cyan-500/30 bg-[#061026] text-cyan-200 shadow-sm hover:border-cyan-400 hover:text-white transition-all duration-300 font-sans">
                Graphic Designer
              </span>
              <span className="px-4 py-1.5 rounded-full text-xs font-semibold border border-cyan-500/30 bg-[#061026] text-cyan-200 shadow-sm hover:border-cyan-400 hover:text-white transition-all duration-300 font-sans">
                Restaurant Branding Specialist
              </span>
              <span className="px-4 py-1.5 rounded-full text-xs font-semibold border border-cyan-500/30 bg-[#061026] text-cyan-200 shadow-sm hover:border-cyan-400 hover:text-white transition-all duration-300 font-sans">
                Digital QR Menu &amp; Web
              </span>
            </motion.div>

            {/* Description Lead text */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: 0.45 }}
              className="space-y-3 max-w-xl mx-auto"
            >
              <p className="text-slate-300 text-base md:text-lg leading-relaxed font-normal font-sans">
                <span className="text-white font-bold">Hello, I'm Amir Hamza</span> — Your Creative Designer &amp; Freelancer
                <br className="hidden sm:inline" />
                {" "}I craft modern, eye-catching and high-converting visual designs for your business to help you attract more customers &amp; grow.
              </p>
              <p className="font-['Kaushan_Script','Caveat',cursive] text-xl sm:text-2xl md:text-3xl text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-sky-300 to-cyan-200 pt-1">
                Let’s create something amazing Together!
              </p>
            </motion.div>

            {/* Primary CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: 0.55 }}
              className="flex flex-col sm:flex-row gap-4 justify-center pt-3 transform-gpu w-full max-w-md sm:max-w-none"
            >
              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-full text-sm font-black text-black bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 shadow-md hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] font-sans cursor-pointer border border-cyan-200/50"
              >
                Hire Me
                <ArrowRight size={16} strokeWidth={3} />
              </a>
              <a
                href="https://wa.me/917054307887"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-full text-sm font-bold border border-emerald-500/40 bg-[#062016]/90 hover:bg-[#083020] text-emerald-300 shadow-sm hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] font-sans cursor-pointer"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12.04 2c-5.46 0-9.9 4.44-9.9 9.9 0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.9-4.44 9.9-9.9 0-2.64-1.03-5.13-2.9-7C17.18 3.03 14.68 2 12.04 2z"/>
                </svg>
                WhatsApp Me
              </a>
              <a
                href="tel:+917054307887"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 rounded-full text-sm font-bold border border-cyan-500/30 bg-[#061126]/80 hover:bg-[#091838] text-cyan-200 shadow-sm hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 font-sans cursor-pointer"
              >
                <Phone size={16} />
                +91 7054307887
              </a>
            </motion.div>

          </div>
          
        </div>
      </div>
    </section>
  );
}
